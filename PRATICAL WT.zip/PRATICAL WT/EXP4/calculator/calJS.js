function addition(){
    var num1=parseInt(document.getElementById("FirstNo").value);
    var num2=parseInt(document.getElementById("SecondNo").value);

    var res=num1+num2;

    document.getElementById("Result").value=res;

}

function substraction(){
    var num1=parseInt(document.getElementById("FirstNo").value);
    var num2=parseInt(document.getElementById("SecondNo").value);

    var res=num1-num2;

    document.getElementById("Result").value=res;

}

function multiplication(){
    var num1=parseInt(document.getElementById("FirstNo").value);
    var num2=parseInt(document.getElementById("SecondNo").value);

    var res=num1*num2;

    document.getElementById("Result").value=res;

}

function division(){
    var num1=parseInt(document.getElementById("FirstNo").value);
    var num2=parseInt(document.getElementById("SecondNo").value);

    var res=num1/num2;

    document.getElementById("Result").value=res;

}