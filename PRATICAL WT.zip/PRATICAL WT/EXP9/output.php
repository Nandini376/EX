<!DOCTYPE HTML>  
<html>
<head>
</head>
<body>  

<h2>Your Input:</h2>
<?php
$name = $_GET['name'];
$email = $_GET['email'];
$website = $_GET['website'];
$comment = $_GET['comment'];
$gender = $_GET['gender'];

echo "Name: $name<br>";
echo "Email: $email<br>";
echo "Website: $website<br>";
echo "Comment: $comment<br>";
echo "Gender: $gender";
?>

</body>
</html>
