document.getElementById("registrationForm").addEventListener("submit", function(event) {
  event.preventDefault();

  var fullName = document.getElementById("fullName").value;
  var age = document.getElementById("age").value;
  var address = document.getElementById("address").value;
  var aadhar = document.getElementById("aadhar").value;
  var mobile = document.getElementById("mobile").value;
  var dob = document.getElementById("dob").value;

  var isValidAadhar = /^\d{12}$/.test(aadhar);

  var isValidMobile = /^\d{10}$/.test(mobile);

  if (age >= 18 && isValidAadhar && isValidMobile) {
    document.getElementById("message").innerHTML = "Thank you, " + fullName + "! Your registration is successful.";
  } else {
    if (age < 18) {
      document.getElementById("message").innerHTML = "Sorry, " + fullName + ". You must be at least 18 years old to register.";
    } else if (!isValidAadhar) {
      document.getElementById("message").innerHTML = "Invalid Aadhar card number. Please enter a 12-digit number.";
    } else if (!isValidMobile) {
      document.getElementById("message").innerHTML = "Invalid mobile number. Please enter a 10-digit number.";
    }
  }
});
